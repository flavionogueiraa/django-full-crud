from .main import PROJECT_NAME, base_dir, get_project_dir

__all__ = [
    PROJECT_NAME,
    base_dir,
    get_project_dir,
]
