def blank_init_script():
    return f"""
__all__ = [

]
"""
