# Django full crud!
Esse pacote serve para você criar um CRUD das suas models de forma que os arquvos sejam criados automaticamente.

## Instalação
```shell
pip install django-full-crud
```

## Dependências
Django

## Principais funcionalidades
- Criação do arquivo admin
- Criação do arquivo de forms
- Criação dos templates (delete, detail, form e list)
- Criação dos views (create, delete, detail, list e update)
- Criação dos paths presentes no urls.py
- Criação dos arquivos inits das pastas

## Recomendações
Criar suas apps com a estrutura fornecida por esse modelo:
https://github.com/TimeNovaData/django_app_modelo
