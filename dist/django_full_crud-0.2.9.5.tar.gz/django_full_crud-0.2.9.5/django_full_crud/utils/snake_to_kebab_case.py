def snake_to_kebab_case(snake_str):
    return snake_str.replace("_", "-")
